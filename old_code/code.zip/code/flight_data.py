import pandas as pd
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import multiprocessing
from lxml import etree
import datetime
import time
import tqdm
import requests
import psycopg2



def read_table_write_rows(date_cal, origin, dest):

	for table in date_cal:
		soup = BeautifulSoup(table.get_attribute('innerHTML')
							 , "html.parser")
		records = []
		for i in soup.find_all('td'):
			try: 
				month = soup.find('span', {
					'class':'ui-datepicker-month'}).text
				
				date = datetime.datetime.strptime(
					i['data-year']+month+i.text.split()[0], '%Y%B%d')
			
				price = int(i.text.split()[1].replace(',', ''))

				last_date = date
				# print(origin, dest, date, price, current_date)
				record = (origin, dest, date, price)
				print(record)

				records.append(record)

			except Exception as error:
				print(error)
				pass

		HEADERS = ({'User-Agent':
						'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 \
                        (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36', \
					'Accept-Language': 'en-US, en;q=0.5'})

		connection = psycopg2.connect(user="avossmeyer",
									  password="surfbro1#",
									  host="surf-forecasts.c6bioghb9ybm.us-east-2.rds.amazonaws.com",
									  port="5432",
									  database="postgres")

		cursor = connection.cursor()

		postgres_insert_query = """ 
							INSERT INTO flight_prices 
							(origin, dest, flight_date, price, etl_insert_timestamp) 
							VALUES 
							(%s,%s,%s,%s,current_timestamp)
						"""

		result = cursor.executemany(postgres_insert_query, records)
		connection.commit()


# Selenium (requires browser)
def scrape_skiplagged(origin='LAX', dest='DPS'):
	driver = webdriver.Chrome()
	tom = datetime.datetime.today().date() + datetime.timedelta(days=1)
	URL = "https://skiplagged.com/flights/{}/{}/{}".format(
		origin, 
		dest, 
		tom.strftime("%Y-%m-%d"))
	print(URL)
	driver.get(URL)
	
	time.sleep(3)

	date = driver.find_element(By.CLASS_NAME, "hasDatepicker")
	date.click()
	
	date_cal = driver.find_elements(By.CLASS_NAME, "ui-datepicker-group")
	read_table_write_rows(date_cal, origin, dest)

	nex = driver.find_elements(By.CLASS_NAME, "ui-icon-circle-triangle-e")
	nex[0].click()
	nex = driver.find_elements(By.CLASS_NAME, "ui-icon-circle-triangle-e")
	nex[0].click()

	date_cal = driver.find_elements(By.CLASS_NAME, "ui-datepicker-group")
	read_table_write_rows(date_cal, origin, dest)

# BeautifulSoup (doesn't require selenium)
def scrape_expedia(origin='LAX', dest='DPS'):
	HEADERS = ({'User-Agent':
		'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 \
		(KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',\
		'Accept-Language': 'en-US, en;q=0.5'})


	URL = 'https://www.expedia.com/Flights-Search?flight-type=on&mode=search&trip=oneway&leg1=from:({}),to:({}),departure:{}'+\
	'TANYT&options=cabinclass:economy&fromDate=9/3/2023&passengers=adults:1,infantinlap:N'.format(origin, dest, '9/3/2023')

	webpage = requests.get(URL, headers=HEADERS)
	soup = BeautifulSoup(webpage.content, "html.parser")
	dom = etree.HTML(str(soup))

	prices = soup.find('ul', class_='uitk-date-range').find_all('tr')[2].find_all('td')


def scrape_one_param(od):
	scrape_skiplagged(od[0], od[1])


def scrape_fast(input_data, num_processes=48):
	p = multiprocessing.Pool(48)  # Create a multiprocessing Pool
	for i in tqdm(p.imap_unordered(scrape_one_param, input_data)):
		i


if __name__ == '__main__':
	scrape_skiplagged('LAX', 'DPS')
	scrape_skiplagged('DPS', 'LAX')



