# from queries import best_iata_surf


app_query = """
select                 
    
    iata_code as "Airport"
    , INITCAP(city) || ', ' || INITCAP(country) as "City"
    -- , round(avg(avg_10d_rating), 2) as "Average Rating"
    , round(avg(max_10d_rating), 2) as "Average Rating"
    , round(avg(dist)::numeric, 2) as "Average Break Distance from Airport"
    , count(*) as "Number of Breaks"
    , round(avg(perc_5_plus)*100, 1)::varchar as "Percent of Breaks 5 Star Plus"
    --, array_agg((break_name, b.dist))
    , array_agg(break_name) as Breaks
from airports_closest_breaks
where airport_size = 'large_airport'
and dist < 100
group by 1,2
order by "Average Rating" desc
"""



create_flight_prices_table_query = """
DROP TABLE flight_prices; 

    CREATE TABLE flight_prices
    (
        origin        VARCHAR(5),
        dest          VARCHAR(5),
        flight_date   DATE,
        price         DOUBLE PRECISION,
        etl_insert_timestamp   TIMESTAMP
    ); 
"""

create_surf_ratings_table_query = """
-- DROP TABLE surf_ratings; 
CREATE TABLE surf_ratings
  (
     break_name     VARCHAR(50),
     break_url      VARCHAR(100),
     time           VARCHAR(15),
     rating         INT,
     period         INT,
     wind           INT,
     wind_state     VARCHAR(20),
     wave_height    DOUBLE PRECISION,
     wave_direction VARCHAR(20),
     --   latitude     int               ,
     --   latitude     char   ( 1)       ,
     lat_decimal    DOUBLE PRECISION,
     lon_decimal    DOUBLE PRECISION,
     create_date    TIMESTAMP,
     ith_forecast   INT,
     id             SERIAL PRIMARY KEY
  ); 
"""


create_acb_materialized_view_query = """
drop materialized view airports_closest_breaks;

CREATE MATERIALIZED VIEW airports_closest_breaks
AS
with airport as (
	SELECT 
		a.iata_code
		, lat_decimal 
		, lon_decimal 
		, type as airport_size
		, name,country,city,municipality
	FROM airports a 
	left join airport_size asize
		on upper(asize.iata_code) = upper(a.iata_code)
--	where type ='large_airport'
--	ORDER BY distance;
)

--select type, count(*) from airport_size group by 1

, good_surf as (
select 
	break_name
	, lat_decimal
	, lon_decimal
	, max(rating) as max_10d_rating
	, avg(rating) as avg_10d_rating
	, avg(case when rating >= 5 then 1 else 0 end) as perc_5_plus
from surf_ratings sr
where lat_decimal is not null and rating <= 10
group by 1,2,3
)

--, B as (
select 
	iata_code
	, airport_size
	, A.name
	, A.country
	, A.city
	, A.municipality
	, avg_10d_rating
	, perc_5_plus
	, max_10d_rating
	, A.dist
	, break_name
	, A.lat_decimal as airport_lat
	, A.lon_decimal as airport_lon
	, good_surf.lat_decimal as break_lat
	, good_surf.lon_decimal as break_lon
from good_surf
JOIN LATERAL (
	SELECT 
		point(A.lat_decimal, A.lon_decimal)::point <@>  (point(good_surf.lat_decimal, good_surf.lon_decimal)::point) as dist
		, A.*
	FROM airport A
	ORDER BY point(A.lat_decimal, A.lon_decimal)::point <@>  (point(good_surf.lat_decimal, good_surf.lon_decimal)::point)
	limit 1
) AS A
on true
--where A.dist < 75
WITH NO data;

REFRESH MATERIALIZED VIEW airports_closest_breaks ;
"""


best_iata_surf_query = """
with A as (
	SELECT 
		a.iata_code
		, lat_decimal 
		, lon_decimal 
		, type as airport_size
	FROM airports a 
	left join airport_size asize
		on upper(asize.iata_code) = upper(a.iata_code)
	where type = 'large_airport'
--	ORDER BY distance;
)

--select type, count(*) from airport_size group by 1

, good_surf as (
select 
	break_name
	, lat_decimal
	, lon_decimal
	, max(rating) as max_10d_rating
	, avg(rating) as avg_10d_rating
from surf_ratings sr
where lat_decimal is not null and rating <= 10
group by 1,2,3
)

, B as (
select 
--	good_surf.lon_decimal
--	, good_surf.break_name
--	, good_surf.lat_decimal
--	, good_surf.max_10d_rating
--	, b.iata_code
--	, b.dist
	iata_code
	, airport_size
	, avg(avg_10d_rating) as avg_10d_rating
	, count(*) as num_good_surf_spots
	, avg(b.dist) as avg_dist
	, array_agg((break_name, b.dist))

from good_surf
JOIN LATERAL (
	SELECT 
		point(A.lat_decimal, A.lon_decimal)::point <@>  (point(good_surf.lat_decimal, good_surf.lon_decimal)::point) as dist
		, *
	FROM A
	ORDER BY point(A.lat_decimal, A.lon_decimal)::point <@>  (point(good_surf.lat_decimal, good_surf.lon_decimal)::point)
	limit 1
) AS b
on true
where b.dist < 75
group by 1,2
order by 3 desc
)

select 
	*
from B
where num_good_surf_spots > 5
order by airport_size, avg_10d_rating desc
--group by 1
"""